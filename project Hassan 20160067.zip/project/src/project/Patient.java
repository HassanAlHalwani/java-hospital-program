/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.io.*;
import java.util.*;
/**
 *
 * @author hassa
 */
public class Patient {
    String pid, pname, phone,email,address,allergy,id_of_doctor,sex,disease, admit_status;
    void new_patient()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("id:-");
        pid = input.nextLine();
        System.out.print("name:-");
        pname = input.nextLine();
        System.out.print("sex:-");
        sex = input.nextLine();
        System.out.print("phone:-");
        phone = input.nextLine();
        System.out.print("email:-");
        email = input.nextLine();
        System.out.print("address:-");
        address = input.nextLine();
        System.out.print("allergy:-");
        allergy = input.nextLine();
        System.out.print("disease:-");
        disease = input.nextLine();
        System.out.print("id_of_doctor:-");         
        id_of_doctor = input.nextLine();
        System.out.print("admit_status:-");         
        admit_status = input.nextLine();
    }
    void patient_info()
    {
        System.out.println(pid + "\t" + pname + "\t" + sex + "\t"+ phone + "\t" + email + "\t" + address + "\t" + allergy + "\t" +disease + "\t"+ id_of_doctor+ "\t" );
    }    
}
    
