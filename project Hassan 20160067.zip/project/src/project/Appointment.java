/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.io.*;
import java.util.*;
/**
 *
 * @author hassa
 */
public class Appointment {
    String aid,date,pid,did;     
    void appointment()     
    {         
        Scanner input = new Scanner(System.in);         
        System.out.print("aid:-");         
        aid = input.nextLine();         
        System.out.print("date:-");         
        date = input.nextLine();         
        System.out.print("pid:-");        
        pid = input.nextLine();
        System.out.print("did:-");        
        did = input.nextLine();    
    }     
    void appointment_info()     
    {         
        System.out.println(aid + "\t" + date + "\t" + pid + "\t" + did);     
    } 
    void app (){
         System.out.println(date +"\t"+did+"\t"+pid);
}
    
}
