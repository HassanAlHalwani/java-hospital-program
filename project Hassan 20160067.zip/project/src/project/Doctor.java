/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.io.*;
import java.util.*;
/**
 *
 * @author hassa
 */
public class Doctor {
      String did, dname, specialist, phone;
    void new_doctor()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("id:-");
        did = input.nextLine();
        System.out.print("name:-");
        dname = input.nextLine();
        System.out.print("specilization:-");
        specialist = input.nextLine();
        System.out.print("phone:-");
        phone = input.nextLine();
    }
    void doctor_info()
    {
        System.out.println(did + "\t" + dname + "\t" + specialist + "\t" + phone);
    }
    
}
